// injected.js
// Runs in MAIN world — has access to the real WebSocket constructor
// Patches WebSocket to intercept Whatnot's OBS WebSocket messages
// Watches for SetStreamServiceSettings and extracts the bearer token

(function() {
  'use strict';

  const OriginalWebSocket = window.WebSocket;

  function PatchedWebSocket(url, protocols) {
    const ws = protocols
      ? new OriginalWebSocket(url, protocols)
      : new OriginalWebSocket(url);

    // Only intercept connections to the OBS WebSocket address
    if (typeof url === 'string' && url.includes('127.0.0.1:4455')) {

      const originalAddEventListener = ws.addEventListener.bind(ws);
      const originalOnMessage = Object.getOwnPropertyDescriptor(WebSocket.prototype, 'onmessage');

      // Intercept via addEventListener
      ws.addEventListener('message', function(event) {
        try {
          const data = JSON.parse(event.data);
          checkForToken(data);
        } catch(e) {
          // Not JSON — ignore
        }
      });

      // Also patch send() so we can see outgoing messages if needed (passive — no interference)
      const originalSend = ws.send.bind(ws);
      ws.send = function(data) {
        try {
          const parsed = JSON.parse(data);
          // Outgoing — passive logging only, no interference
        } catch(e) {}
        return originalSend(data);
      };
    }

    return ws;
  }

  // Copy all static properties from original WebSocket
  Object.setPrototypeOf(PatchedWebSocket, OriginalWebSocket);
  Object.setPrototypeOf(PatchedWebSocket.prototype, OriginalWebSocket.prototype);

  // Copy constants (CONNECTING, OPEN, etc.)
  ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED'].forEach(function(key) {
    Object.defineProperty(PatchedWebSocket, key, {
      value: OriginalWebSocket[key],
      writable: false,
      enumerable: true,
      configurable: false
    });
  });

  window.WebSocket = PatchedWebSocket;

  function checkForToken(data) {
    // Match the exact structure we confirmed from DevTools:
    // op: 6, requestType: "SetStreamServiceSettings"
    if (
      data &&
      data.op === 6 &&
      data.d &&
      data.d.requestType === 'SetStreamServiceSettings' &&
      data.d.requestData &&
      data.d.requestData.streamServiceSettings &&
      data.d.requestData.streamServiceSettings.bearer_token
    ) {
      const token = data.d.requestData.streamServiceSettings.bearer_token;
      const server = data.d.requestData.streamServiceSettings.server || 'https://global.whip.live-video.net';

      // Send to content script via postMessage
      window.postMessage({
        type: 'RIPREADY_TOKEN_INTERCEPTED',
        token: token,
        server: server,
        timestamp: Date.now()
      }, '*');

      console.log('[RipReady] Bearer token intercepted and sent to RipReady.');
    }
  }

})();
